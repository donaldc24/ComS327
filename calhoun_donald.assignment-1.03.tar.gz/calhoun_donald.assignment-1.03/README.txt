This is my Terrian Generation c code for 1.03, which meets all of the specified requirements as follows:
	- Added three types of Trainers: Hiker, Rival, Boater along with PC
	- Implemented Dijkstras algo to find the distance from every node to the player
	- Prints distance maps for each type of trainer in the specified format