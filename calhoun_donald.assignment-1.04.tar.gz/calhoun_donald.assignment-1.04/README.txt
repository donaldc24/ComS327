This is my Terrian Generation c code for 1.04, which meets all of the specified requirements as follows:
	- Added switch "--numtrainers" which allows user to input number of trainers generated
	- Added movement for 7 different NPC types: Hiker, Rival, Boater, Pacer, Wanderer, Stationary, and Walkers
	- Used the PQ I used from 1.03 to store the NPC types and movements
	- Used usleep(25000) to update and reprint the map